# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(tallow src/tallow.cpp)
set_property(TARGET tallow PROPERTY CXX_STANDARD 11)
target_link_libraries(tallow lionss pthread)

add_executable(ember-8 src/ember-8.cpp)
set_property(TARGET ember-8 PROPERTY CXX_STANDARD 11)
target_link_libraries(ember-8 lionss pthread)

add_executable(tlb_shootdown src/tlb_shootdown.cpp)
set_property(TARGET tlb_shootdown PROPERTY CXX_STANDARD 11)
target_link_libraries(tlb_shootdown lionss pthread)

add_executable(tiering-osr src/tiering-osr.cpp)
set_property(TARGET tiering-osr PROPERTY CXX_STANDARD 11)
target_link_libraries(tiering-osr lionss pthread)

add_executable(feldspar src/feldspar.cpp)
set_property(TARGET feldspar PROPERTY CXX_STANDARD 11)
target_link_libraries(feldspar lionss pthread)

add_executable(redis_slotmove src/redis_slotmove.cpp)
set_property(TARGET redis_slotmove PROPERTY CXX_STANDARD 11)
target_link_libraries(redis_slotmove lionss pthread)

add_executable(apparmor_profile src/apparmor_profile.cpp)
set_property(TARGET apparmor_profile PROPERTY CXX_STANDARD 11)
target_link_libraries(apparmor_profile lionss pthread)

add_executable(yuv420pack src/yuv420pack.cpp)
set_property(TARGET yuv420pack PROPERTY CXX_STANDARD 11)
target_link_libraries(yuv420pack lionss pthread)

add_executable(etl_gold_rollup src/etl_gold_rollup.cpp)
set_property(TARGET etl_gold_rollup PROPERTY CXX_STANDARD 11)
target_link_libraries(etl_gold_rollup lionss pthread)

add_executable(mesh_route src/mesh_route.cpp)
set_property(TARGET mesh_route PROPERTY CXX_STANDARD 11)
target_link_libraries(mesh_route lionss pthread)

add_executable(I2cRecover src/I2cRecover.cpp)
set_property(TARGET I2cRecover PROPERTY CXX_STANDARD 11)
target_link_libraries(I2cRecover lionss pthread)

add_executable(cteInline src/cteInline.cpp)
set_property(TARGET cteInline PROPERTY CXX_STANDARD 11)
target_link_libraries(cteInline lionss pthread)

add_executable(TurnRelay src/TurnRelay.cpp)
set_property(TARGET TurnRelay PROPERTY CXX_STANDARD 11)
target_link_libraries(TurnRelay lionss pthread)

add_executable(xxhash3 src/xxhash3.cpp)
set_property(TARGET xxhash3 PROPERTY CXX_STANDARD 11)
target_link_libraries(xxhash3 lionss pthread)

add_executable(isingMetropolis src/isingMetropolis.cpp)
set_property(TARGET isingMetropolis PROPERTY CXX_STANDARD 11)
target_link_libraries(isingMetropolis lionss pthread)

add_executable(bbr-probe src/bbr-probe.cpp)
set_property(TARGET bbr-probe PROPERTY CXX_STANDARD 11)
target_link_libraries(bbr-probe lionss pthread)

add_executable(predicate_pushdown src/predicate_pushdown.cpp)
set_property(TARGET predicate_pushdown PROPERTY CXX_STANDARD 11)
target_link_libraries(predicate_pushdown lionss pthread)

add_executable(reactionWheel src/reactionWheel.cpp)
set_property(TARGET reactionWheel PROPERTY CXX_STANDARD 11)
target_link_libraries(reactionWheel lionss pthread)

add_executable(bleGattNotify src/bleGattNotify.cpp)
set_property(TARGET bleGattNotify PROPERTY CXX_STANDARD 11)
target_link_libraries(bleGattNotify lionss pthread)

add_executable(jitterbuffer src/jitterbuffer.cpp)
set_property(TARGET jitterbuffer PROPERTY CXX_STANDARD 11)
target_link_libraries(jitterbuffer lionss pthread)

add_executable(harrier src/harrier.cpp)
set_property(TARGET harrier PROPERTY CXX_STANDARD 11)
target_link_libraries(harrier lionss pthread)

add_executable(emaDecay src/emaDecay.cpp)
set_property(TARGET emaDecay PROPERTY CXX_STANDARD 11)
target_link_libraries(emaDecay lionss pthread)

add_executable(fzf-preview src/fzf-preview.cpp)
set_property(TARGET fzf-preview PROPERTY CXX_STANDARD 11)
target_link_libraries(fzf-preview lionss pthread)

add_executable(mvccVacuum src/mvccVacuum.cpp)
set_property(TARGET mvccVacuum PROPERTY CXX_STANDARD 11)
target_link_libraries(mvccVacuum lionss pthread)

add_executable(umbra src/umbra.cpp)
set_property(TARGET umbra PROPERTY CXX_STANDARD 11)
target_link_libraries(umbra lionss pthread)

add_executable(marmot src/marmot.cpp)
set_property(TARGET marmot PROPERTY CXX_STANDARD 11)
target_link_libraries(marmot lionss pthread)

add_executable(tinwhistle src/tinwhistle.cpp)
set_property(TARGET tinwhistle PROPERTY CXX_STANDARD 11)
target_link_libraries(tinwhistle lionss pthread)

add_executable(dedupeBlock src/dedupeBlock.cpp)
set_property(TARGET dedupeBlock PROPERTY CXX_STANDARD 11)
target_link_libraries(dedupeBlock lionss pthread)

add_executable(helmLint src/helmLint.cpp)
set_property(TARGET helmLint PROPERTY CXX_STANDARD 11)
target_link_libraries(helmLint lionss pthread)

add_executable(duckdbprobe src/duckdbprobe.cpp)
set_property(TARGET duckdbprobe PROPERTY CXX_STANDARD 11)
target_link_libraries(duckdbprobe lionss pthread)

