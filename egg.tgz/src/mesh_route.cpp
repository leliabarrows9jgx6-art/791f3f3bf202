// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Route mesh packet\n", stdout);
  return lionss_run_workload("mesh_route");
}
